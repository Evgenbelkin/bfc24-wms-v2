'use strict';

require('dotenv').config();

const app = require('./src/app');
const config = require('./src/config');
const { testConnection, pool } = require('./src/config/database');
const logger = require('./src/utils/logger');
const wbAutoSync = require('./src/jobs/wbAutoSync');
const wbStockSync = require('./src/jobs/wbStockSync');
const wbItemsSync = require('./src/jobs/wbItemsSync');
const storageBilling = require('./src/jobs/storageBilling');
const wbTariffsSync = require('./src/jobs/wbTariffsSync');
const wbAcceptanceSync = require('./src/jobs/wbAcceptanceSync'); // ВЫКЛЮЧЕНО 30.08.2026: метод WB acceptance/coefficients временно отключён Wildberries с 15.08.2026
const wbFbsStatusSync = require('./src/jobs/wbFbsStatusSync');
const wbStockReconcileAlert = require('./src/jobs/wbStockReconcileAlert');
const wbStatsRegionSync = require('./src/jobs/wbStatsRegionSync');

// =============================================================================
// Server entry point с graceful shutdown
// =============================================================================

let server;

async function start() {
  // Проверяем подключение к БД перед стартом
  try {
    const dbInfo = await testConnection();
    logger.info({ db: dbInfo.db, time: dbInfo.now }, 'Database connection OK');
  } catch (err) {
    logger.fatal({ err }, 'Failed to connect to database. Exiting.');
    process.exit(1);
  }

  server = app.listen(config.server.port, '0.0.0.0', () => {
    logger.info(
      {
        port:   config.server.port,
        env:    config.env,
        prefix: config.server.apiPrefix,
      },
      `BFC24 WMS v2 started on port ${config.server.port}`
    );
  });

  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      logger.fatal({ port: config.server.port }, 'Port already in use');
    } else {
      logger.fatal({ err }, 'Server error');
    }
    process.exit(1);
  });

  wbAutoSync.start();
  wbStockSync.start();
  wbItemsSync.start();
  storageBilling.start();
  wbTariffsSync.start();
  // wbAcceptanceSync.start(); // ВЫКЛЮЧЕНО: метод WB acceptance/coefficients временно отключён Wildberries (см. dev.wildberries.ru, запись от 15.08.2026)
  wbFbsStatusSync.start();
  wbStockReconcileAlert.start();
  wbStatsRegionSync.start();
}

// ---------------------------------------------------------------------------
// Graceful shutdown
// ---------------------------------------------------------------------------
async function shutdown(signal) {
  logger.info(`Received ${signal}, starting graceful shutdown...`);
  wbAutoSync.stop();
  wbStockSync.stop();
  wbItemsSync.stop();
  storageBilling.stop();
  wbTariffsSync.stop();
  // wbAcceptanceSync.stop(); // ВЫКЛЮЧЕНО вместе со start()
  wbFbsStatusSync.stop();
  wbStockReconcileAlert.stop();
  wbStatsRegionSync.stop();

  if (server) {
    server.close(async () => {
      logger.info('HTTP server closed');
      try {
        await pool.end();
        logger.info('Database pool closed');
      } catch (err) {
        logger.error({ err }, 'Error closing database pool');
      }
      process.exit(0);
    });

    // Принудительное завершение через 10 секунд
    setTimeout(() => {
      logger.warn('Forced shutdown after timeout');
      process.exit(1);
    }, 10_000).unref();
  } else {
    process.exit(0);
  }
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT',  () => shutdown('SIGINT'));

// Необработанные исключения
process.on('uncaughtException', (err) => {
  logger.fatal({ err }, 'Uncaught exception');
  process.exit(1);
});
process.on('unhandledRejection', (reason) => {
  logger.fatal({ reason }, 'Unhandled promise rejection');
  process.exit(1);
});

start();
